// script.js

function sendMessage() {
    let userInput = document.getElementById('userInput').value;
    displayUserMessage(userInput);
    // Call function to send userInput to your AI service and get a response
    // For example, using Fetch API to communicate with the chatbot API
    fetch('/your-chatbot-api-endpoint', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: userInput }),
    })
    .then(response => response.json())
    .then(data => {
        displayBotMessage(data.response); // Display bot's response
    })
    .catch(error => console.error('Error:', error));
}

function displayUserMessage(message) {
    // Display user message in the chat container
    let chatContainer = document.getElementById('chatContainer');
    chatContainer.innerHTML += `<div>User: ${message}</div>`;
}

function displayBotMessage(message) {
    // Display bot's response in the chat container
    let chatContainer = document.getElementById('chatContainer');
    chatContainer.innerHTML += `<div>Bot: ${message}</div>`;
}
